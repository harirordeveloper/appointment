jQuery ->
        $('#product').dataTable()
